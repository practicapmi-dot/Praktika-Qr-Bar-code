"""Конфигурация нормализатора штрих-кодов.

Все настраиваемые параметры собраны здесь, чтобы их было удобно
подбирать под конкретный поток данных (разрешение, освещение и т.п.).
"""
from dataclasses import dataclass


@dataclass
class NormalizerConfig:
    # --- Кроп / padding ---
    # Bbox гарантированно вмещает код, но может захватывать фон и текст.
    # Небольшой запас на случай, если код почти у границы.
    #pad_ratio: float = 0.12          # доля от размера bbox, добавляемая по краям
    pad_ratio: float = 0.12

    # --- Предобработка ---
    use_clahe: bool = True
    clahe_clip: float = 2.0
    clahe_grid: int = 8
    # Вычитание фона (устранение неравномерного освещения/бликов).
    subtract_background: bool = True
    bg_kernel_frac: float = 0.5      # размер морф-ядра относительно min(H,W) кропа
    # Мягкое шумоподавление с сохранением краёв.
    bilateral_d: int = 5
    bilateral_sigma_color: float = 40.0
    bilateral_sigma_space: float = 40.0

    # --- Сегментация зоны полос ---
    # Окно для оценки локальной "однонаправленности" градиента.
    coherence_win: int = 9
    coherence_thresh: float = 0.35   # порог когерентности [0..1] для зоны полос
    # Морфология для объединения полос в единый регион.
    
    '''
    morph_close_frac: float = 0.25   # ядро закрытия относительно размера кропа
    '''
    morph_close_frac: float = 0.15
    
    min_region_frac: float = 0.05    # мин. площадь региона относительно кропа

    # --- Оценка ориентации ---
    n_angle_bins: int = 180          # бинов гистограммы направлений (0..180)
    use_fft_refine: bool = True
    fft_consistency_deg: float = 12.0  # макс. расхождение градиент/FFT, иначе доверяем градиенту

    # --- Углы прямоугольника / перспектива ---
    corner_refine: bool = True
    # Коррекция перспективы по схождению полос (после поворота к вертикали).
    correct_perspective: bool = True
    # Мин. относительный скос (tan) для применения коррекции; меньше — игнор.
    perspective_min_shear: float = 0.08
    # Насколько сильно допускаем схождение полос (защита от абсурдных гомографий).
    max_perspective_ratio: float = 3.0

    # --- Выход ---
    target_height: int = 256         # апскейл выпрямленного кода до этой высоты
    keep_aspect: bool = True         # ширину масштабировать пропорционально
    max_width: int = 2048            # ограничение ширины после апскейла
    output_grayscale: bool = False   # True -> одноканальный выход
    interpolation: str = "lanczos"   # cubic | lanczos

    # --- Прочее ---
    orient_bars_vertical: bool = True  # финально: полосы строго вертикальны
