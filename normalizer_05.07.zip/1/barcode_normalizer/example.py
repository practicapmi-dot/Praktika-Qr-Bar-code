"""Пример использования barcode_normalizer.

Запуск:
    python -m barcode_normalizer.example путь_к_кадру.jpg
или без аргументов — обработает встроенные примеры кропов (если есть).
"""
import sys
import cv2

from . import normalize_barcode, batch_normalize, NormalizerConfig


def demo_single(image_path, bbox):
    img = cv2.imread(image_path)
    cfg = NormalizerConfig(
        target_height=256,       # апскейл выпрямленного кода до 256 px по высоте
        output_grayscale=False,  # цветной выход; True -> grayscale
        correct_perspective=True,
    )
    # Одиночная нормализация:
    result = normalize_barcode(img, bbox, cfg)
    cv2.imwrite("normalized.png", result)
    print("Сохранено normalized.png, размер:", result.shape)

    # Пакетная нормализация нескольких bbox из одного кадра:
    bboxes = [bbox]  # список (x1, y1, x2, y2)
    results = batch_normalize(img, bboxes, cfg)
    print("Пакет:", [None if r is None else r.shape for r in results])

    # Debug-режим — визуализация всех шагов конвейера:
    from .debug import render_debug
    _, dbg = normalize_barcode(img, bbox, cfg, debug=True)
    render_debug(dbg, save_path="debug_steps.png")
    print("Debug-панель: debug_steps.png")


if __name__ == "__main__":
    if len(sys.argv) >= 2:
        path = sys.argv[1]
        im = cv2.imread(path)
        h, w = im.shape[:2]
        # bbox по умолчанию = весь кадр (замените на реальные координаты)
        #demo_single(path, (0, 0, w, h))
        #demo_single(path, (745, 270, 1015, 451)) #sample_frame.png
        demo_single(path, (523, 378, 578, 422)) #image.jpg
    else:
        print("Использование: python -m barcode_normalizer.example кадр.jpg")
