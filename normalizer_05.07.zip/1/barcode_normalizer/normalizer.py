"""Главный конвейер нормализации 1D штрих-кодов (ориентация ведёт геометрию).

Порядок:
  1. Кроп по bbox (+padding).
  2. Предобработка (grayscale, вычитание фона, CLAHE, denoise).
  3. Оценка угла полос (structure tensor + FFT). angle = направление ВДОЛЬ
     полос (90° = вертикаль).
  4. Поворот кропа на (angle - 90): полосы становятся вертикальными.
  5. Сегментация зоны полос на повёрнутом изображении.
  6. Поиск четырёхугольника зоны (трапеция => перспектива) и гомография
     в прямоугольник фиксированной высоты (апскейл встроен).
  7. Финальная проверка вертикальности + формат выхода.

API:
    normalize_barcode(image, bbox, cfg=None, debug=False)
    batch_normalize(image, bboxes, cfg=None)
"""
import cv2
import numpy as np

from .config import NormalizerConfig
from . import preprocess as pp
from . import orientation as ori
from . import segment as seg
from . import perspective as persp


def _crop_with_padding(image, bbox, cfg):
    h, w = image.shape[:2]
    x1, y1, x2, y2 = bbox
    x1, x2 = sorted((int(x1), int(x2)))
    y1, y2 = sorted((int(y1), int(y2)))
    bw, bh = x2 - x1, y2 - y1
    px = int(round(bw * cfg.pad_ratio))
    py = int(round(bh * cfg.pad_ratio))
    nx1, ny1 = max(0, x1 - px), max(0, y1 - py)
    nx2, ny2 = min(w, x2 + px), min(h, y2 + py)
    return image[ny1:ny2, nx1:nx2].copy(), (nx1, ny1, nx2, ny2)


def _ensure_bars_vertical(warped):
    """Страховка: если вдруг полосы вышли горизонтальными — повернуть на 90°.

    У вертикальных полос дисперсия профиля по столбцам >> по строкам.
    """
    g = warped if warped.ndim == 2 else cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    g = g.astype(np.float32)
    var_cols = float(np.var(g.mean(axis=0)))  # вертикальные полосы
    var_rows = float(np.var(g.mean(axis=1)))  # горизонтальные полосы
    if var_rows > var_cols:
        warped = cv2.rotate(warped, cv2.ROTATE_90_CLOCKWISE)
    return warped


def normalize_barcode(image, bbox, cfg: NormalizerConfig = None, debug=False):
    if cfg is None:
        cfg = NormalizerConfig()
    dbg = {} if debug else None

    crop, used_box = _crop_with_padding(image, bbox, cfg)
    if crop.size == 0:
        return (None, dbg) if debug else None
    if debug:
        dbg["crop"] = crop.copy()

    # 1. Предобработка.
    gray_clean, pp_steps = pp.preprocess(crop, cfg)
    if debug:
        dbg["preprocess"] = pp_steps

    # 2. Ориентация полос.
    ori_res = ori.estimate_orientation(gray_clean, cfg)
    angle = ori_res["angle"]  # направление вдоль полос; 90 = вертикаль
    if debug:
        dbg["orientation"] = ori_res

    
    # 3. Поворот к вертикали: полосы -> вертикальные.
    rot_angle = angle - 90.0
    crop_rot, M = persp.rotate_bound(crop, rot_angle)
    gray_rot, _ = persp.rotate_bound(gray_clean, rot_angle)
    if debug:
        dbg["crop_rot"] = crop_rot.copy()
        dbg["rot_angle"] = rot_angle
    
    
    # 4. Сегментация зоны полос на повёрнутом изображении.
    ori_rot = ori.estimate_orientation(gray_rot, cfg)
    score = seg.barcode_score_map(ori_rot["coherence_map"],
                                  ori_rot["energy_map"])
    region_mask, rect = seg.segment_barcode_region(score, cfg)
    if debug:
        dbg["score"] = score
        dbg["region_mask"] = region_mask

    '''
    # 5. Axis-aligned bbox зоны полос на повёрнутом изображении.
    bb = persp.bbox_from_mask(region_mask) if region_mask is not None else None
    if bb is None:
        h, w = crop_rot.shape[:2]
        bb = np.array([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]],
                      dtype=np.float32)
    x1, y1 = bb[0]
    x2, y2 = bb[2]
    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)

    # 6. Оценка перспективы по схождению полос в зоне.
    region_gray = gray_rot[y1:y2, x1:x2]
    corners = np.array([[x1, y1], [x2, y1], [x2, y2], [x1, y2]],
                       dtype=np.float32)
    
    if cfg.correct_perspective and region_gray.size > 0 and region_gray.shape[0] > 8:
        t_top, t_bot = persp.estimate_shear(region_gray)
        rh = (y2 - y1)
        # смещение верхних/нижних углов для компенсации схождения
        shear = (t_top - t_bot)
        # Истинная перспектива (схождение) — когда наклон сверху и снизу
        # противоположны по знаку (полосы "веером"). Иначе это
        # остаточный общий наклон — его убираем чистым доповоротом.
        opposite = (t_top * t_bot) < 0
        if abs(shear) >= cfg.perspective_min_shear and opposite:
            # полосы в верхней части наклонены на t_top, в нижней — t_bot.
            # Строим трапецию: сдвигаем верх и низ так, чтобы выровнять.
            dx_top = -t_top * (rh / 2.0)
            dx_bot = t_bot * (rh / 2.0)
            dx_top = float(np.clip(dx_top, -(x2 - x1), (x2 - x1)))
            dx_bot = float(np.clip(dx_bot, -(x2 - x1), (x2 - x1)))
            corners = np.array([
                [x1 + dx_top, y1], [x2 + dx_top, y1],
                [x2 + dx_bot, y2], [x1 + dx_bot, y2]], dtype=np.float32)
    
    ''''''        
    #DEBUG
    from .perspective import order_corners
    corners = order_corners(cv2.boxPoints(rect))
    print(corners)
    ''''''
    
    if debug:
        dbg["corners"] = corners.copy()
    '''
    
    # 5. Получение четырёхугольника области штрихкода.
    corners = None
    quad_mode = None

    if region_mask is not None and cv2.countNonZero(region_mask) > 0:
        if cfg.correct_perspective:
            # Настоящий четырёхугольник по контуру маски.
            '''03.07 вариант 1
            if region_mask is not None and cv2.countNonZero(region_mask) > 0:
                mask_for_quad = region_mask.copy()

                h_mask, w_mask = mask_for_quad.shape[:2]

                kx = max(3, int(w_mask * 0.01))
                ky = max(3, int(h_mask * 0.01))

                if kx % 2 == 0:
                    kx += 1

                if ky % 2 == 0:
                    ky += 1

                dilate_kernel = cv2.getStructuringElement(
                    cv2.MORPH_RECT,
                    (kx, ky)
                )

                mask_for_quad = cv2.dilate(
                    mask_for_quad,
                    dilate_kernel,
                    iterations=3
                )

                #print("DEBUG mask_for_quad.shape:", mask_for_quad.shape)
                
                corners = persp.quad_from_mask(mask_for_quad, cfg)
            '''
            
            corners = persp.quad_from_mask(region_mask, cfg)
            
            
            if corners is not None:
                quad_mode = "contour_quad"

        # Если четырёхугольник получить не удалось,
        # используем повёрнутый прямоугольник как fallback.
        if corners is None and rect is not None:
            corners = persp.order_corners(cv2.boxPoints(rect))
            quad_mode = "min_area_rect"

        # Следующий fallback — обычный bbox.
        if corners is None:
            corners = persp.bbox_from_mask(region_mask)
            quad_mode = "axis_aligned_bbox"

    # Последний fallback — весь повёрнутый кроп.
    if corners is None:
        h, w = crop_rot.shape[:2]
        corners = np.array([
            [0, 0],
            [w - 1, 0],
            [w - 1, h - 1],
            [0, h - 1]
        ], dtype=np.float32)
        quad_mode = "full_crop"

    if debug:
        dbg["corners"] = corners.copy()
        dbg["quad_mode"] = quad_mode
    
    # Гомография зоны -> прямоугольник (апскейл встроен).
    out_w, out_h = persp.build_target_size(corners, cfg)
    warped = persp.warp_to_rect(crop_rot, corners, out_w, out_h, cfg)
    
    #added 03.07
    if cfg.orient_bars_vertical:
        warped = _ensure_bars_vertical(warped)

    # 7. Формат выхода (вертикальность уже гарантирована оценкой угла).
    if cfg.output_grayscale and warped.ndim == 3:
        warped = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)

    if debug:
        dbg["result"] = warped.copy()
        return warped, dbg
    return warped


def batch_normalize(image, bboxes, cfg: NormalizerConfig = None):
    if cfg is None:
        cfg = NormalizerConfig()
    out = []
    for bb in bboxes:
        try:
            out.append(normalize_barcode(image, bb, cfg, debug=False))
        except Exception as e:
            print("Ошибка при итерации:", len(out))
            print(e)
            out.append(None)
    return out
