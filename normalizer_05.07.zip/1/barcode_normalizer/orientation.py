"""Оценка ориентации полос 1D штрих-кода.

Соглашение об угле: `angle` — направление ВДОЛЬ полос в градусах,
0° = горизонталь (полосы идут по оси X, т.е. лежачие),
90° = вертикаль (полосы стоячие). Цель нормализации — привести к 90°.

Основной метод — проекционный (Radon-подобный) поиск:
  для набора углов проецируем изображение на ось, перпендикулярную
  предполагаемому направлению полос, и измеряем "резкость" профиля.
  Когда направление проецирования совпадает с нормалью к полосам,
  профиль имеет максимальную дисперсию (чёткие пики светлых/тёмных).

Плюс тензор структуры — для карт когерентности/энергии (сегментация)
и как грубая начальная оценка.
"""
import cv2
import numpy as np

from .config import NormalizerConfig


def structure_tensor(gray: np.ndarray, win: int):
    """Карты для сегментации: orientation, coherence, energy."""
    g = gray.astype(np.float32) / 255.0
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
    jxx, jyy, jxy = gx * gx, gy * gy, gx * gy
    if win % 2 == 0:
        win += 1
    ksize = (win, win)
    jxx = cv2.GaussianBlur(jxx, ksize, 0)
    jyy = cv2.GaussianBlur(jyy, ksize, 0)
    jxy = cv2.GaussianBlur(jxy, ksize, 0)
    tmp = np.sqrt((jxx - jyy) ** 2 + 4 * jxy ** 2)
    lam1 = 0.5 * (jxx + jyy + tmp)
    lam2 = 0.5 * (jxx + jyy - tmp)
    coherence = np.clip((lam1 - lam2) / (lam1 + lam2 + 1e-6), 0, 1)
    energy = lam1 + lam2
    return coherence, energy


def _projection_sharpness(gray_f, angle_along_bars_deg):
    """Резкость профиля при проекции вдоль полос.

    Если полосы идут под углом `angle_along_bars_deg`, то усреднение
    ВДОЛЬ полос (сумма по направлению полос) даёт 1D-профиль по нормали,
    где чередование тёмных/светлых максимально выражено. Меряем дисперсию
    градиента этого профиля (чем резче переходы, тем лучше выравнивание).
    """
    h, w = gray_f.shape[:2]
    # Повернём так, чтобы полосы стали вертикальными: поворот на (angle-90).
    rot = angle_along_bars_deg - 90.0
    M = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), rot, 1.0)
    cos, sin = abs(M[0, 0]), abs(M[0, 1])
    nw = int(h * sin + w * cos)
    nh = int(h * cos + w * sin)
    M[0, 2] += (nw - w) / 2.0
    M[1, 2] += (nh - h) / 2.0
    r = cv2.warpAffine(gray_f, M, (nw, nh), flags=cv2.INTER_LINEAR,
                       borderMode=cv2.BORDER_REFLECT)
    # Профиль по столбцам (среднее по строкам): для вертикальных полос
    # даёт чёткую пилу. Меряем энергию его производной.
    prof = r.mean(axis=0)
    d = np.diff(prof)
    return float(np.sum(d * d))


def _vertical_periodicity(gray_f, angle_along_bars_deg):
    """Мера того, насколько при данном угле полосы образуют
    регулярную вертикальную пилу (а не случайные края).

    Считаем энергию спектра 1D-профиля вне нулевой частоты:
    у настоящего штрих-кода энергия сосредоточена в полосе частот.
    """
    h, w = gray_f.shape[:2]
    rot = angle_along_bars_deg - 90.0
    M = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), rot, 1.0)
    cos, sin = abs(M[0, 0]), abs(M[0, 1])
    nw = int(h * sin + w * cos)
    nh = int(h * cos + w * sin)
    M[0, 2] += (nw - w) / 2.0
    M[1, 2] += (nh - h) / 2.0
    r = cv2.warpAffine(gray_f, M, (nw, nh), flags=cv2.INTER_LINEAR,
                       borderMode=cv2.BORDER_REFLECT)
    # Усредняем по строкам -> 1D профиль поперёк полос.
    # Важно: усредняем только центральную полосу по высоте,
    # чтобы края/фон меньше мешали.
    hh = r.shape[0]
    band_rows = r[hh // 4: 3 * hh // 4] if hh >= 8 else r
    prof = band_rows.mean(axis=0)
    prof = prof - prof.mean()
    if len(prof) < 8:
        return 0.0
    spec = np.abs(np.fft.rfft(prof * np.hanning(len(prof))))
    if len(spec) < 4:
        return 0.0
    band = spec[2:]
    # Пиковость: отношение максимума к среднему (сколь выражен
    # единый период полос). У настоящих вертикальных полос — высокое.
    peak = float(np.max(band))
    mean = float(np.mean(band)) + 1e-6
    return peak * (peak / mean)


def estimate_angle_projection(gray, coarse_step=3.0, fine_step=0.5):
    """Ищет угол ВДОЛЬ полос перебором + разрешает 90°-неоднозначность."""
    g = gray.astype(np.float32) / 255.0
    best_a, best_s = 0.0, -1
    for a in np.arange(0, 180, coarse_step):
        s = _projection_sharpness(g, a)
        if s > best_s:
            best_s, best_a = s, a
    lo, hi = best_a - coarse_step, best_a + coarse_step
    for a in np.arange(lo, hi + 1e-6, fine_step):
        s = _projection_sharpness(g, a % 180)
        if s > best_s:
            best_s, best_a = s, a % 180
    best_a %= 180.0

    # Разрешение неоднозначности: кандидат best_a и best_a-90.
    # Выбираем тот, где вертикальная периодичность сильнее
    # (у настоящих полос — выраженный период поперёк).
    cand = [best_a, (best_a - 90.0) % 180.0]
    scores = [_vertical_periodicity(g, c) for c in cand]
    best = cand[int(np.argmax(scores))]
    return float(best % 180), float(best_s)


def estimate_orientation(gray_clean: np.ndarray, cfg: NormalizerConfig):
    """Итог: angle (вдоль полос, 90=вертикаль) + карты для сегментации."""
    coherence, energy = structure_tensor(gray_clean, cfg.coherence_win)
    angle, sharp = estimate_angle_projection(gray_clean)
    return {
        "angle": float(angle),
        "coherence_map": coherence,
        "energy_map": energy,
        "confidence": float(sharp),
        "method": "projection",
    }
