import cv2
from barcode_normalizer import normalize_barcode, batch_normalize, NormalizerConfig

frame = cv2.imread("image.jpg")
#bbox = (x1, y1, x2, y2)          # осевой bounding box кода


bbox0 = (395, 465, 425, 525)
bbox1 = (942, 355, 983, 375)
bbox2 = (523, 378, 578, 422)
bbox3 = (510, 740, 539, 762)
bboxes = [bbox0, bbox1, bbox2, bbox3]

cfg = NormalizerConfig(
    target_height=256,           # высота выпрямленного кода (апскейл)
    output_grayscale=False,      # True -> одноканальный выход
    correct_perspective=True,    # коррекция перспективы
)

# один код
#norm = normalize_barcode(frame, bbox, cfg)

# несколько кодов из одного кадра
norms = batch_normalize(frame, bboxes, cfg)
for i in range(len(norms)):
    #cv2.imwrite(f"normalized{i}.png", norms[i])
    cv2.imwrite("results/normalized" + str(i) + ".png", norms[i])
    print(f"Сохранено normalized{i}.png, размер:", norms[i].shape)

from barcode_normalizer.debug import render_debug
for i in range(len(norms)):
    _, dbg = normalize_barcode(frame, bboxes[i], cfg, debug=True)
    render_debug(dbg, save_path="results/debug_steps"  + str(i) + ".png")

'''
# режим отладки: вернёт (result, dbg) со всеми промежуточными шагами
result, dbg = normalize_barcode(frame, bbox, cfg, debug=True)
from barcode_normalizer.debug import render_debug
render_debug(dbg, save_path="debug.png")
'''